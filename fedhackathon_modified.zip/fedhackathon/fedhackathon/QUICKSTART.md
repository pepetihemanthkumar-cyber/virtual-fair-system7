# Quick Start Guide

## Getting Started in 2 Minutes

### Step 1: Open the Application

**Option 1: Direct File**
- Simply double-click `index.html` to open in your default browser

**Option 2: Local Server (Recommended)**
```bash
# Using Python 3
python -m http.server 8000

# Using Node.js
npx http-server

# Using PHP
php -S localhost:8000
```

Then open `http://localhost:8000` in your browser.

### Step 2: Login as Admin

- Go to the login page
- Use credentials:
  - **Username**: `admin`
  - **Password**: `admin123`

### Step 3: Create Your First Career Fair

1. Click "Create Career Fair" button
2. Fill in the details:
   - Title: "Spring 2024 Career Fair"
   - Description: "Join us for our annual career fair..."
   - Start Date: Select a future date/time
   - End Date: Select an end date/time
3. Click "Create"

### Step 4: Add Company Booths

1. Click "Manage Booths" on your career fair
2. Click "Add Booth"
3. Fill in company information:
   - Company Name: "Tech Corp"
   - Description: "Leading technology company..."
   - Industry: "Technology"
   - Website: "https://techcorp.com"
   - Logo URL: (optional) URL to company logo
4. Click "Add Booth"
5. Repeat for more companies

### Step 5: Test as a User

1. Logout from admin account
2. Click "Sign Up" to create a user account
3. Fill in your details and register
4. Login with your new account
5. Browse career fairs and register
6. Visit company booths, submit resumes, and chat!

## Key Features to Try

### Admin Features
- ✅ Create and manage career fairs
- ✅ Add/edit/delete company booths
- ✅ View all user registrations
- ✅ Monitor fair activity

### User Features
- ✅ Register for career fairs
- ✅ Browse company booths
- ✅ Submit resumes to companies
- ✅ Chat in company booths
- ✅ Network with other job seekers

## Important Notes

### Data Storage
- All data is stored in your browser's localStorage
- Data is browser-specific (won't sync across browsers)
- Clearing browser data will delete all information

### Default Admin Account
- Username: `admin`
- Password: `admin123`
- Created automatically on first load

## Troubleshooting

### Page Not Loading
- Make sure JavaScript is enabled
- Check browser console for errors (F12)
- Try a different browser

### Data Not Saving
- Check browser localStorage permissions
- Make sure you're not in private/incognito mode
- Try clearing cache and reloading

### Features Not Working
- Refresh the page
- Clear browser cache
- Check browser console for errors

## Next Steps

- Customize the styling in `static/css/style.css`
- Add more features in the JavaScript files
- Modify data structure in `static/js/dataService.js`
- Deploy to a static hosting service (GitHub Pages, Netlify, etc.)

Happy networking! 🚀
