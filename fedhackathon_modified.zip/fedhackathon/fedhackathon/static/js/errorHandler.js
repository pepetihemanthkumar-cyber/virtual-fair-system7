// Global Error Handler for Smooth Error Management

// Global error handler
window.addEventListener('error', (event) => {
    console.error('Global error:', event.error);
    
    // Don't show error notifications for known issues
    if (event.error && (
        event.error.message.includes('advancedFeatures') ||
        event.error.message.includes('qrService') ||
        event.error.message.includes('gamificationService')
    )) {
        // Silently handle missing optional features
        return;
    }
    
    // Show user-friendly error message
    if (typeof showNotification !== 'undefined') {
        showNotification('Something went wrong. Please refresh the page.', 'error', 5000);
    }
});

// Handle unhandled promise rejections
window.addEventListener('unhandledrejection', (event) => {
    console.error('Unhandled promise rejection:', event.reason);
    
    // Prevent default browser error handling
    event.preventDefault();
    
    // Show user-friendly message
    if (typeof showNotification !== 'undefined') {
        showNotification('An error occurred. Please try again.', 'error', 5000);
    }
});

// Safe function wrapper for optional features
window.safeCall = function(fn, fallback = null) {
    try {
        if (typeof fn === 'function') {
            return fn();
        }
        return fallback;
    } catch (error) {
        console.warn('Safe call error:', error);
        return fallback;
    }
};

// Safe property access
window.safeGet = function(obj, path, defaultValue = null) {
    try {
        const keys = path.split('.');
        let result = obj;
        for (const key of keys) {
            if (result === null || result === undefined) {
                return defaultValue;
            }
            result = result[key];
        }
        return result !== undefined ? result : defaultValue;
    } catch (error) {
        return defaultValue;
    }
};

// Initialize error handling
document.addEventListener('DOMContentLoaded', () => {
    // Check for critical services
    if (typeof storage === 'undefined') {
        console.error('Storage service not loaded');
    }
    
    if (typeof userService === 'undefined') {
        console.error('User service not loaded');
    }
});


