let currentFairId = null;

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    loadFairs();
    setupEventListeners();
});

function setupEventListeners() {
    const createFairForm = document.getElementById('createFairForm');
    
    // Setup form validation
    setupFormValidation(createFairForm, {
        fairTitle: [validators.required, validators.minLength(3), validators.maxLength(200)],
        fairDescription: [validators.maxLength(1000)],
        fairStartDate: [validators.required],
        fairEndDate: [validators.required]
    });
    
    // Create Fair Form
    createFairForm.addEventListener('submit', (e) => {
        e.preventDefault();
        
        // Validate form
        if (!validateForm(createFairForm, {
            fairTitle: [validators.required, validators.minLength(3), validators.maxLength(200)],
            fairStartDate: [validators.required],
            fairEndDate: [validators.required]
        })) {
            showNotification('Please fix the errors in the form', 'error');
            return;
        }
        
        const submitButton = createFairForm.querySelector('button[type="submit"]');
        setButtonLoading(submitButton, true);
        
        const formData = {
            title: document.getElementById('fairTitle').value.trim(),
            description: document.getElementById('fairDescription').value.trim(),
            start_date: document.getElementById('fairStartDate').value,
            end_date: document.getElementById('fairEndDate').value
        };
        
        // Validate date range
        const startDate = new Date(formData.start_date);
        const endDate = new Date(formData.end_date);
        if (endDate <= startDate) {
            setButtonLoading(submitButton, false);
            showNotification('End date must be after start date', 'error');
            return;
        }
        
        // Simulate delay for better UX
        setTimeout(() => {
            const result = fairService.create(formData);
            
            setButtonLoading(submitButton, false);
            
            if (result.success) {
                showNotification('Career fair created successfully!', 'success');
                closeModal('createFairModal');
                createFairForm.reset();
                // Clear validation states
                createFairForm.querySelectorAll('.valid, .invalid').forEach(el => {
                    el.classList.remove('valid', 'invalid');
                });
                createFairForm.querySelectorAll('.field-error').forEach(el => el.remove());
                loadFairs();
            } else {
                showNotification(result.message || 'Failed to create career fair', 'error');
            }
        }, 300);
    });
    
    // Create Booth Form
    const createBoothForm = document.getElementById('createBoothForm');
    setupFormValidation(createBoothForm, {
        boothCompanyName: [validators.required, validators.minLength(2), validators.maxLength(200)],
        boothDescription: [validators.maxLength(1000)],
        boothIndustry: [validators.maxLength(100)],
        boothWebsite: [validators.url],
        boothLogoUrl: [validators.url]
    });
    
    createBoothForm.addEventListener('submit', (e) => {
        e.preventDefault();
        if (!currentFairId) {
            showNotification('Please select a career fair first', 'error');
            return;
        }
        
        // Validate form
        if (!validateForm(createBoothForm, {
            boothCompanyName: [validators.required, validators.minLength(2), validators.maxLength(200)]
        })) {
            showNotification('Please fix the errors in the form', 'error');
            return;
        }
        
        const submitButton = createBoothForm.querySelector('button[type="submit"]');
        setButtonLoading(submitButton, true);
        
        const formData = {
            company_name: document.getElementById('boothCompanyName').value.trim(),
            description: document.getElementById('boothDescription').value.trim(),
            industry: document.getElementById('boothIndustry').value.trim(),
            website: document.getElementById('boothWebsite').value.trim(),
            logo_url: document.getElementById('boothLogoUrl').value.trim(),
            career_fair_id: currentFairId
        };
        
        setTimeout(() => {
            const result = boothService.create(formData);
            
            setButtonLoading(submitButton, false);
            
            if (result.success) {
                showNotification('Booth added successfully!', 'success');
                closeModal('createBoothModal');
                createBoothForm.reset();
                // Clear validation states
                createBoothForm.querySelectorAll('.valid, .invalid').forEach(el => {
                    el.classList.remove('valid', 'invalid');
                });
                createBoothForm.querySelectorAll('.field-error').forEach(el => el.remove());
                loadBooths(currentFairId);
            } else {
                showNotification(result.message || 'Failed to add booth', 'error');
            }
        }, 300);
    });
}

function showTab(tabName) {
    document.querySelectorAll('.tab-content').forEach(tab => tab.classList.remove('active'));
    document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
    
    document.getElementById(`${tabName}Tab`).classList.add('active');
    event.target.classList.add('active');
    
    if (tabName === 'registrations') {
        loadRegistrations();
    }
}

function showCreateFairModal() {
    showModal('createFairModal');
}

function showCreateBoothModal() {
    showModal('createBoothModal');
}

function loadFairs() {
    const container = document.getElementById('fairsList');
    container.innerHTML = '<div class="loading"><div class="spinner"></div> Loading career fairs...</div>';
    
    setTimeout(() => {
        const fairs = fairService.getAll('admin');
        
        // Get booth counts and registration counts
        const booths = storage.get('booths', []);
        const registrations = storage.get('registrations', []);
        
        const fairsWithCounts = fairs.map(fair => {
            const fairBooths = booths.filter(b => b.career_fair_id === fair.id);
            const fairRegistrations = registrations.filter(r => r.career_fair_id === fair.id);
            return {
                ...fair,
                booth_count: fairBooths.length,
                registration_count: fairRegistrations.length
            };
        });
        
        if (fairsWithCounts.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-calendar-times"></i>
                    <h3>No career fairs yet</h3>
                    <p>Create your first career fair to get started!</p>
                    <button class="btn btn-primary" onclick="showCreateFairModal()" style="margin-top: 1rem;">
                        <i class="fas fa-plus"></i> Create Career Fair
                    </button>
                </div>
            `;
            return;
        }
        
        container.innerHTML = fairsWithCounts.map(fair => `
            <div class="fair-card">
                <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 1rem;">
                    <div>
                        <h3>${fair.title}</h3>
                        <p style="color: var(--text-secondary); margin: 0.5rem 0;">${fair.description || 'No description'}</p>
                    </div>
                    <span class="status-badge status-${fair.status || 'upcoming'}">${fair.status || 'upcoming'}</span>
                </div>
                <div class="fair-meta">
                    <span><i class="fas fa-calendar"></i> ${formatDate(fair.start_date)}</span>
                    <span><i class="fas fa-building"></i> ${fair.booth_count} booths</span>
                    <span><i class="fas fa-users"></i> ${fair.registration_count} registrations</span>
                </div>
                <div style="display: flex; gap: 0.5rem; margin-top: 1rem;">
                    <button class="btn btn-primary" onclick="manageBooths(${fair.id})" style="flex: 1;">
                        <i class="fas fa-building"></i> Manage Booths
                    </button>
                    <button class="btn btn-secondary" onclick="editFair(${fair.id})">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="btn btn-danger" onclick="deleteFair(${fair.id})">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </div>
        `).join('');
    }, 300);
}

function manageBooths(fairId) {
    currentFairId = fairId;
    showModal('manageBoothsModal');
    loadBooths(fairId);
}

function loadBooths(fairId) {
    const container = document.getElementById('boothsList');
    container.innerHTML = '<div class="loading"><div class="spinner"></div> Loading booths...</div>';
    
    setTimeout(() => {
        const booths = boothService.getByFairId(fairId);
        
        if (booths.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-building"></i>
                    <h3>No booths yet</h3>
                    <p>Add your first company booth to get started!</p>
                    <button class="btn btn-primary" onclick="showCreateBoothModal()" style="margin-top: 1rem;">
                        <i class="fas fa-plus"></i> Add Booth
                    </button>
                </div>
            `;
            return;
        }
        
        container.innerHTML = `
            <div class="booths-grid">
                ${booths.map(booth => `
                    <div class="booth-card">
                        ${booth.logo_url ? `<img src="${booth.logo_url}" alt="${booth.company_name}" style="width: 100%; height: 150px; object-fit: cover; border-radius: 0.5rem; margin-bottom: 1rem;" onerror="this.style.display='none'">` : ''}
                        <h3>${booth.company_name}</h3>
                        <p style="color: var(--text-secondary); font-size: 0.9rem;">${booth.industry || 'No industry specified'}</p>
                        <p style="margin: 0.5rem 0; font-size: 0.9rem;">${booth.description || 'No description'}</p>
                        <div style="display: flex; gap: 0.5rem; margin-top: 1rem;">
                            <button class="btn btn-secondary" onclick="editBooth(${booth.id})" style="flex: 1;">
                                <i class="fas fa-edit"></i> Edit
                            </button>
                            <button class="btn btn-danger" onclick="deleteBooth(${booth.id})">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </div>
                `).join('')}
            </div>
        `;
    }, 300);
}

function editFair(fairId) {
    const fair = fairService.getById(fairId);
    
    if (!fair) {
        showNotification('Fair not found', 'error');
        return;
    }
    
    document.getElementById('fairTitle').value = fair.title;
    document.getElementById('fairDescription').value = fair.description || '';
    document.getElementById('fairStartDate').value = fair.start_date.substring(0, 16);
    document.getElementById('fairEndDate').value = fair.end_date.substring(0, 16);
    
    // Update modal title
    const modalHeader = document.querySelector('#createFairModal .modal-header h2');
    if (modalHeader) modalHeader.textContent = 'Edit Career Fair';
    
    // Update form to handle edit
    const form = document.getElementById('createFairForm');
    const originalSubmit = form.onsubmit;
    
    form.onsubmit = (e) => {
        e.preventDefault();
        
        // Validate form
        if (!validateForm(form, {
            fairTitle: [validators.required, validators.minLength(3), validators.maxLength(200)],
            fairStartDate: [validators.required],
            fairEndDate: [validators.required]
        })) {
            showNotification('Please fix the errors in the form', 'error');
            return;
        }
        
        const submitButton = form.querySelector('button[type="submit"]');
        setButtonLoading(submitButton, true);
        
        const formData = {
            title: document.getElementById('fairTitle').value.trim(),
            description: document.getElementById('fairDescription').value.trim(),
            start_date: document.getElementById('fairStartDate').value,
            end_date: document.getElementById('fairEndDate').value
        };
        
        // Validate date range
        const startDate = new Date(formData.start_date);
        const endDate = new Date(formData.end_date);
        if (endDate <= startDate) {
            setButtonLoading(submitButton, false);
            showNotification('End date must be after start date', 'error');
            return;
        }
        
        setTimeout(() => {
            const updateResult = fairService.update(fairId, formData);
            
            setButtonLoading(submitButton, false);
            
            if (updateResult.success) {
                showNotification('Career fair updated successfully!', 'success');
                closeModal('createFairModal');
                form.reset();
                form.onsubmit = originalSubmit;
                if (modalHeader) modalHeader.textContent = 'Create Career Fair';
                loadFairs();
            } else {
                showNotification(updateResult.message || 'Failed to update career fair', 'error');
            }
        }, 300);
    };
    
    showModal('createFairModal');
}

function deleteFair(fairId) {
    if (!confirm('Are you sure you want to delete this career fair? This will also delete all associated booths and registrations.')) {
        return;
    }
    
    const result = fairService.delete(fairId);
    
    if (result.success) {
        showNotification('Career fair deleted successfully', 'success');
        loadFairs();
    } else {
        showNotification(result.message || 'Failed to delete career fair', 'error');
    }
}

function editBooth(boothId) {
    if (!currentFairId) {
        showNotification('Please select a career fair first', 'error');
        return;
    }
    
    const booth = boothService.getById(boothId);
    
    if (!booth) {
        showNotification('Booth not found', 'error');
        return;
    }
    
    document.getElementById('boothCompanyName').value = booth.company_name;
    document.getElementById('boothDescription').value = booth.description || '';
    document.getElementById('boothIndustry').value = booth.industry || '';
    document.getElementById('boothWebsite').value = booth.website || '';
    document.getElementById('boothLogoUrl').value = booth.logo_url || '';
    
    // Update modal title
    const modalHeader = document.querySelector('#createBoothModal .modal-header h2');
    if (modalHeader) modalHeader.textContent = 'Edit Company Booth';
    
    const form = document.getElementById('createBoothForm');
    const originalSubmit = form.onsubmit;
    
    form.onsubmit = (e) => {
        e.preventDefault();
        
        // Validate form
        if (!validateForm(form, {
            boothCompanyName: [validators.required, validators.minLength(2), validators.maxLength(200)]
        })) {
            showNotification('Please fix the errors in the form', 'error');
            return;
        }
        
        const submitButton = form.querySelector('button[type="submit"]');
        setButtonLoading(submitButton, true);
        
        const formData = {
            company_name: document.getElementById('boothCompanyName').value.trim(),
            description: document.getElementById('boothDescription').value.trim(),
            industry: document.getElementById('boothIndustry').value.trim(),
            website: document.getElementById('boothWebsite').value.trim(),
            logo_url: document.getElementById('boothLogoUrl').value.trim()
        };
        
        setTimeout(() => {
            const updateResult = boothService.update(boothId, formData);
            
            setButtonLoading(submitButton, false);
            
            if (updateResult.success) {
                showNotification('Booth updated successfully!', 'success');
                closeModal('createBoothModal');
                form.reset();
                form.onsubmit = originalSubmit;
                if (modalHeader) modalHeader.textContent = 'Add Company Booth';
                loadBooths(currentFairId);
            } else {
                showNotification(updateResult.message || 'Failed to update booth', 'error');
            }
        }, 300);
    };
    
    showModal('createBoothModal');
}

function deleteBooth(boothId) {
    if (!confirm('Are you sure you want to delete this booth?')) {
        return;
    }
    
    const result = boothService.delete(boothId);
    
    if (result.success) {
        showNotification('Booth deleted successfully', 'success');
        loadBooths(currentFairId);
    } else {
        showNotification(result.message || 'Failed to delete booth', 'error');
    }
}

function loadRegistrations() {
    const container = document.getElementById('registrationsList');
    container.innerHTML = '<div class="loading"><div class="spinner"></div> Loading registrations...</div>';
    
    setTimeout(() => {
        const registrations = registrationService.getAll();
        const users = storage.get('users', []);
        const fairs = storage.get('fairs', []);
        
        const registrationsWithDetails = registrations.map(reg => {
            const user = users.find(u => u.id === reg.user_id);
            const fair = fairs.find(f => f.id === reg.career_fair_id);
            return {
                ...reg,
                username: user ? user.username : 'Unknown',
                full_name: user ? user.full_name : '',
                email: user ? user.email : '',
                fair_title: fair ? fair.title : 'Unknown Fair'
            };
        });
        
        if (registrationsWithDetails.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-users"></i>
                    <h3>No registrations yet</h3>
                    <p>User registrations will appear here once users start registering for career fairs.</p>
                </div>
            `;
            return;
        }
        
        container.innerHTML = `
            <div style="overflow-x: auto;">
                <table style="width: 100%; border-collapse: collapse;">
                    <thead>
                        <tr style="background: var(--bg-color);">
                            <th style="padding: 1rem; text-align: left; border-bottom: 2px solid var(--border-color);">User</th>
                            <th style="padding: 1rem; text-align: left; border-bottom: 2px solid var(--border-color);">Email</th>
                            <th style="padding: 1rem; text-align: left; border-bottom: 2px solid var(--border-color);">Career Fair</th>
                            <th style="padding: 1rem; text-align: left; border-bottom: 2px solid var(--border-color);">Registered At</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${registrationsWithDetails.map(reg => `
                            <tr style="border-bottom: 1px solid var(--border-color);">
                                <td style="padding: 1rem;">${reg.full_name || reg.username}</td>
                                <td style="padding: 1rem;">${reg.email}</td>
                                <td style="padding: 1rem;">${reg.fair_title}</td>
                                <td style="padding: 1rem;">${formatDate(reg.registered_at)}</td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
        `;
    }, 300);
}
