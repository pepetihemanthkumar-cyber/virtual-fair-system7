let currentRoomId = null;

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    loadFairs();
    initializeChat();
});

function initializeChat() {
    // Setup chat message listener
    if (!window.chatListeners) {
        window.chatListeners = {};
    }
}

function loadFairs() {
    const container = document.getElementById('fairsGrid');
    container.innerHTML = '<div class="loading"><div class="spinner"></div> Loading career fairs...</div>';
    
    setTimeout(() => {
        const fairs = fairService.getAll('user');
        const registrations = registrationService.getAll();
        const currentUser = userService.getCurrentUser();
        const booths = storage.get('booths', []);
        
        const fairsWithStatus = fairs.map(fair => {
            const isRegistered = registrations.some(
                r => r.user_id === currentUser.id && r.career_fair_id === fair.id
            );
            const fairBooths = booths.filter(b => b.career_fair_id === fair.id);
            return {
                ...fair,
                is_registered: isRegistered,
                booth_count: fairBooths.length
            };
        });
        
        if (fairsWithStatus.length === 0) {
            container.innerHTML = `
                <div class="empty-state">
                    <i class="fas fa-calendar-times"></i>
                    <h3>No upcoming career fairs</h3>
                    <p>Check back later for new opportunities!</p>
                </div>
            `;
            return;
        }
        
        container.innerHTML = fairsWithStatus.map(fair => `
            <div class="fair-card" onclick="viewFair(${fair.id})">
                <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 1rem;">
                    <h3>${fair.title}</h3>
                    <span class="status-badge status-${fair.status || 'upcoming'}">${fair.status || 'upcoming'}</span>
                </div>
                <p style="color: var(--text-secondary); margin-bottom: 1rem;">${fair.description || 'No description available'}</p>
                <div class="fair-meta">
                    <span><i class="fas fa-calendar"></i> ${formatDate(fair.start_date)}</span>
                    <span><i class="fas fa-building"></i> ${fair.booth_count} companies</span>
                </div>
                ${fair.is_registered ? 
                    '<div style="margin-top: 1rem;"><span class="status-badge status-active">Registered</span></div>' :
                    '<button class="btn btn-primary" style="width: 100%; margin-top: 1rem;" onclick="event.stopPropagation(); registerForFair(' + fair.id + ')">Register Now</button>'
                }
            </div>
        `).join('');
    }, 300);
}

function registerForFair(fairId) {
    const result = registrationService.create(fairId);
    
    if (result.success) {
        showNotification('Successfully registered for the career fair!', 'success');
        loadFairs();
    } else {
        const errorMessage = result.message || 'Registration failed';
        showNotification(errorMessage, 'error');
    }
}

function viewFair(fairId) {
    const fair = fairService.getById(fairId);
    const currentUser = userService.getCurrentUser();
    
    if (!fair) {
        showNotification('Fair not found', 'error');
        return;
    }
    
    // Check if user is registered
    const registrations = registrationService.getAll();
    const isRegistered = registrations.some(
        r => r.user_id === currentUser.id && r.career_fair_id === fairId
    );
    
    if (!isRegistered) {
        showNotification('Please register for this career fair first!', 'warning');
        return;
    }
    
    const booths = boothService.getByFairId(fairId);
    
    document.getElementById('fairDetailTitle').textContent = fair.title;
    document.getElementById('fairDetailContent').innerHTML = `
        <div style="margin-bottom: 2rem;">
            <p style="color: var(--text-secondary); margin-bottom: 1rem;">${fair.description || 'No description'}</p>
            <div class="fair-meta">
                <span><i class="fas fa-calendar"></i> ${formatDate(fair.start_date)} - ${formatDate(fair.end_date)}</span>
            </div>
        </div>
        <h3 style="margin-bottom: 1rem;">Company Booths</h3>
        <div class="booths-grid">
            ${booths.length === 0 ? '<p>No booths available yet.</p>' : booths.map(booth => `
                <div class="booth-card" onclick="viewBooth(${booth.id})">
                    ${booth.logo_url ? `<img src="${booth.logo_url}" alt="${booth.company_name}" style="width: 100%; height: 150px; object-fit: cover; border-radius: 0.5rem; margin-bottom: 1rem;" onerror="this.style.display='none'">` : 
                        `<div style="width: 100%; height: 150px; background: linear-gradient(135deg, var(--primary-color), var(--secondary-color)); border-radius: 0.5rem; margin-bottom: 1rem; display: flex; align-items: center; justify-content: center; color: white; font-size: 3rem;"><i class="fas fa-building"></i></div>`
                    }
                    <h3>${booth.company_name}</h3>
                    <p style="color: var(--text-secondary); font-size: 0.9rem; margin: 0.5rem 0;">${booth.industry || 'No industry specified'}</p>
                    <p style="font-size: 0.9rem;">${booth.description ? (booth.description.length > 100 ? booth.description.substring(0, 100) + '...' : booth.description) : 'No description'}</p>
                    <button class="btn btn-primary" style="width: 100%; margin-top: 1rem;" onclick="event.stopPropagation(); viewBooth(${booth.id})">
                        Visit Booth
                    </button>
                </div>
            `).join('')}
        </div>
        <div style="margin-top: 2rem;">
            <button class="btn btn-secondary" onclick="closeModal('fairDetailModal')">Close</button>
        </div>
    `;
    
    showModal('fairDetailModal');
}

function viewBooth(boothId) {
    const booth = boothService.getById(boothId);
    
    if (!booth) {
        showNotification('Booth not found', 'error');
        return;
    }
    
    // Get chat room
    const chatData = chatService.getRoom(boothId);
    
    document.getElementById('boothDetailTitle').textContent = booth.company_name;
    document.getElementById('boothDetailContent').innerHTML = `
        <div style="margin-bottom: 2rem;">
            ${booth.logo_url ? `<img src="${booth.logo_url}" alt="${booth.company_name}" style="width: 100%; max-height: 200px; object-fit: contain; border-radius: 0.5rem; margin-bottom: 1rem;" onerror="this.style.display='none'">` : ''}
            <p style="color: var(--text-secondary); margin-bottom: 0.5rem;"><strong>Industry:</strong> ${booth.industry || 'Not specified'}</p>
            ${booth.website ? `<p style="margin-bottom: 1rem;"><a href="${booth.website}" target="_blank" style="color: var(--primary-color);">${booth.website}</a></p>` : ''}
            <p style="margin-bottom: 1.5rem;">${booth.description || 'No description available'}</p>
        </div>
        
        <div style="margin-bottom: 2rem;">
            <h3 style="margin-bottom: 1rem;">Submit Resume</h3>
            <form id="resumeForm" class="resume-form" onsubmit="submitResume(event, ${boothId})">
                <div class="form-group">
                    <label>Cover Letter (Optional)</label>
                    <textarea id="coverLetter" rows="4" placeholder="Tell the company why you're interested..."></textarea>
                </div>
                <div class="file-upload" onclick="document.getElementById('resumeFile').click()">
                    <i class="fas fa-cloud-upload-alt" style="font-size: 2rem; color: var(--text-secondary); margin-bottom: 0.5rem;"></i>
                    <p>Click to upload resume (PDF, DOC, DOCX)</p>
                    <input type="file" id="resumeFile" accept=".pdf,.doc,.docx" required>
                    <span id="fileName" style="display: block; margin-top: 0.5rem; color: var(--primary-color);"></span>
                </div>
                <button type="submit" class="btn btn-primary btn-block">Submit Resume</button>
            </form>
        </div>
        
        <div>
            <h3 style="margin-bottom: 1rem;">Live Chat</h3>
            <div class="chat-container" id="chatContainer">
                <div class="chat-messages" id="chatMessages">
                    ${chatData.messages && chatData.messages.length > 0 ? chatData.messages.map(msg => `
                        <div class="chat-message">
                            <div class="chat-message-header">
                                <span class="chat-message-username">${msg.username}</span>
                                <span class="chat-message-time">${formatRelativeTime(msg.sent_at)}</span>
                            </div>
                            <div>${msg.message}</div>
                        </div>
                    `).join('') : '<div class="empty-state" style="padding: 2rem;"><p>No messages yet. Start the conversation!</p></div>'}
                </div>
                <div class="chat-input-container">
                    <input type="text" class="chat-input" id="chatInput" placeholder="Type a message..." onkeypress="handleChatKeyPress(event, ${boothId})">
                    <button class="btn btn-primary" onclick="sendChatMessage(${boothId})">Send</button>
                </div>
            </div>
        </div>
        
        <div style="margin-top: 2rem;">
            <button class="btn btn-secondary" onclick="closeModal('boothDetailModal')">Close</button>
        </div>
    `;
    
    // Join chat room
    currentRoomId = chatData.room_id;
    chatService.onMessage(boothId, (message) => {
        addMessageToChat(message);
    });
    
    // Scroll chat to bottom
    setTimeout(() => {
        const chatMessages = document.getElementById('chatMessages');
        if (chatMessages) {
            chatMessages.scrollTop = chatMessages.scrollHeight;
        }
    }, 100);
    
    // File upload handler
    setTimeout(() => {
        const fileInput = document.getElementById('resumeFile');
        if (fileInput) {
            fileInput.addEventListener('change', (e) => {
                const fileName = e.target.files[0]?.name || '';
                document.getElementById('fileName').textContent = fileName;
            });
        }
    }, 100);
    
    showModal('boothDetailModal');
}

function addMessageToChat(message) {
    const chatMessages = document.getElementById('chatMessages');
    if (!chatMessages) return;
    
    // Remove empty state if exists
    const emptyState = chatMessages.querySelector('.empty-state');
    if (emptyState) emptyState.remove();
    
    const messageDiv = document.createElement('div');
    messageDiv.className = 'chat-message';
    messageDiv.innerHTML = `
        <div class="chat-message-header">
            <span class="chat-message-username">${message.username}</span>
            <span class="chat-message-time">${formatRelativeTime(message.sent_at)}</span>
        </div>
        <div>${message.message}</div>
    `;
    
    chatMessages.appendChild(messageDiv);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

function handleChatKeyPress(event, boothId) {
    if (event.key === 'Enter') {
        sendChatMessage(boothId);
    }
}

function sendChatMessage(boothId) {
    const input = document.getElementById('chatInput');
    const message = input.value.trim();
    
    if (!message) {
        showNotification('Please enter a message', 'warning');
        return;
    }
    
    const result = chatService.addMessage(boothId, message);
    
    if (result.success) {
        // Message will be added via the listener
        input.value = '';
    } else {
        showNotification(result.message || 'Failed to send message', 'error');
    }
}

function submitResume(event, boothId) {
    event.preventDefault();
    
    const form = event.target;
    const submitButton = form.querySelector('button[type="submit"]');
    const fileInput = document.getElementById('resumeFile');
    const coverLetter = document.getElementById('coverLetter');
    
    if (!fileInput.files[0]) {
        showNotification('Please select a resume file', 'error');
        return;
    }
    
    // Validate file type
    const allowedTypes = ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
    const fileType = fileInput.files[0].type;
    if (!allowedTypes.includes(fileType) && !fileInput.files[0].name.match(/\.(pdf|doc|docx)$/i)) {
        showNotification('Please upload a PDF, DOC, or DOCX file', 'error');
        return;
    }
    
    // Validate file size (16MB max)
    const maxSize = 16 * 1024 * 1024; // 16MB
    if (fileInput.files[0].size > maxSize) {
        showNotification('File size must be less than 16MB', 'error');
        return;
    }
    
    setButtonLoading(submitButton, true);
    
    // Convert file to base64 for storage
    const reader = new FileReader();
    reader.onload = (e) => {
        const fileData = {
            name: fileInput.files[0].name,
            data: e.target.result,
            type: fileInput.files[0].type,
            size: fileInput.files[0].size
        };
        
        const result = submissionService.create(boothId, fileData, coverLetter ? coverLetter.value : '');
        
        setButtonLoading(submitButton, false);
        
        if (result.success) {
            showNotification('Resume submitted successfully!', 'success');
            form.reset();
            document.getElementById('fileName').textContent = '';
        } else {
            showNotification(result.message || 'Error submitting resume', 'error');
        }
    };
    
    reader.onerror = () => {
        setButtonLoading(submitButton, false);
        showNotification('Error reading file. Please try again.', 'error');
    };
    
    reader.readAsDataURL(fileInput.files[0]);
}
