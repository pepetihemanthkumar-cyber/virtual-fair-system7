// Advanced Features Service
// Handles: Video Chat, AI Matching, Recommendations, QR Codes, i18n, Gamification

// ============================================
// 1. VIDEO CHAT / LIVE INTERVIEW ROOMS
// ============================================

const videoChatService = {
    createRoom: (boothId, hostId) => {
        const rooms = storage.get('videoRooms', {});
        const roomId = `video_${boothId}_${Date.now()}`;
        
        const room = {
            id: roomId,
            booth_id: boothId,
            host_id: hostId,
            participants: [hostId],
            status: 'active',
            created_at: new Date().toISOString(),
            ended_at: null
        };
        
        rooms[roomId] = room;
        storage.set('videoRooms', rooms);
        
        return { success: true, room };
    },
    
    joinRoom: (roomId, userId) => {
        const rooms = storage.get('videoRooms', {});
        const room = rooms[roomId];
        
        if (!room) {
            return { success: false, message: 'Room not found' };
        }
        
        if (room.status !== 'active') {
            return { success: false, message: 'Room is not active' };
        }
        
        if (!room.participants.includes(userId)) {
            room.participants.push(userId);
            rooms[roomId] = room;
            storage.set('videoRooms', rooms);
        }
        
        return { success: true, room };
    },
    
    getRoom: (roomId) => {
        const rooms = storage.get('videoRooms', {});
        return rooms[roomId] || null;
    },
    
    getRoomsByBooth: (boothId) => {
        const rooms = storage.get('videoRooms', {});
        return Object.values(rooms).filter(r => r.booth_id === boothId && r.status === 'active');
    },
    
    endRoom: (roomId) => {
        const rooms = storage.get('videoRooms', {});
        if (rooms[roomId]) {
            rooms[roomId].status = 'ended';
            rooms[roomId].ended_at = new Date().toISOString();
            storage.set('videoRooms', rooms);
            return { success: true };
        }
        return { success: false, message: 'Room not found' };
    }
};

// ============================================
// 2. AI RESUME SCREENING / MATCHING
// ============================================

const aiMatchingService = {
    // Simple keyword-based matching algorithm
    extractKeywords: (text) => {
        if (!text) return [];
        const commonWords = ['the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by', 'is', 'are', 'was', 'were', 'be', 'been', 'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'should', 'could', 'may', 'might', 'must', 'can'];
        const words = text.toLowerCase().match(/\b[a-z]+\b/g) || [];
        return words.filter(word => word.length > 3 && !commonWords.includes(word));
    },
    
    calculateMatchScore: (resumeText, jobDescription, skills = []) => {
        if (!resumeText || !jobDescription) return 0;
        
        const resumeKeywords = aiMatchingService.extractKeywords(resumeText);
        const jobKeywords = aiMatchingService.extractKeywords(jobDescription);
        
        // Count matching keywords
        const matchingKeywords = resumeKeywords.filter(keyword => 
            jobKeywords.includes(keyword) || 
            jobKeywords.some(jk => jk.includes(keyword) || keyword.includes(jk))
        );
        
        // Skills bonus
        const skillsMatch = skills.filter(skill => 
            jobKeywords.some(jk => jk.includes(skill.toLowerCase()) || skill.toLowerCase().includes(jk))
        ).length;
        
        // Calculate score (0-100)
        const keywordScore = (matchingKeywords.length / Math.max(jobKeywords.length, 1)) * 70;
        const skillsScore = (skillsMatch / Math.max(skills.length, 1)) * 30;
        
        return Math.min(100, Math.round(keywordScore + skillsScore));
    },
    
    matchResumeToBooth: (userId, boothId) => {
        try {
            const submissions = storage.get('resumeSubmissions', []);
            const userSubmission = submissions.find(s => s.user_id === userId && s.booth_id === boothId);
            const booths = storage.get('booths', []);
            const booth = booths.find(b => b.id === boothId);
            
            // If no submission, return a default score based on booth description
            if (!booth) {
                return { success: false, message: 'Booth not found' };
            }
            
            if (!userSubmission) {
                // Return a basic score even without resume
                const jobDescription = booth.description || '';
                const basicScore = jobDescription.length > 0 ? 25 : 0;
                return {
                    success: true,
                    matchScore: basicScore,
                    recommendation: 'Submit resume for better matching',
                    matchedKeywords: []
                };
            }
            
            // Extract resume text (simplified - in real app, would parse PDF)
            const resumeText = userSubmission.cover_letter || '';
            const jobDescription = booth.description || '';
            
            // Get user skills (would come from user profile in real app)
            const users = storage.get('users', []);
            const user = users.find(u => u.id === userId);
            const skills = user?.skills || [];
            
            const matchScore = aiMatchingService.calculateMatchScore(resumeText, jobDescription, skills);
            
            return {
                success: true,
                matchScore,
                recommendation: matchScore >= 70 ? 'Highly Recommended' : 
                               matchScore >= 50 ? 'Good Match' : 
                               matchScore >= 30 ? 'Moderate Match' : 'Low Match',
                matchedKeywords: aiMatchingService.extractKeywords(resumeText)
                    .filter(kw => aiMatchingService.extractKeywords(jobDescription).includes(kw))
            };
        } catch (error) {
            console.error('Error matching resume:', error);
            return {
                success: false,
                message: 'Error calculating match score',
                matchScore: 0
            };
        }
    }
};

// ============================================
// 3. RECOMMENDATION ENGINE
// ============================================

const recommendationService = {
    getUserPreferences: (userId) => {
        const preferences = storage.get('userPreferences', {});
        return preferences[userId] || {
            industries: [],
            skills: [],
            experience_level: 'entry',
            preferred_locations: []
        };
    },
    
    updatePreferences: (userId, preferences) => {
        const allPreferences = storage.get('userPreferences', {});
        allPreferences[userId] = { ...allPreferences[userId], ...preferences };
        storage.set('userPreferences', allPreferences);
        return { success: true };
    },
    
    recommendBooths: (userId) => {
        const userPrefs = recommendationService.getUserPreferences(userId);
        const booths = storage.get('booths', []);
        const bookmarks = bookmarkService.getAll();
        const submissions = storage.get('resumeSubmissions', []);
        const userSubmissions = submissions.filter(s => s.user_id === userId);
        
        // Calculate scores for each booth
        const scoredBooths = booths.map(booth => {
            let score = 0;
            
            // Industry match
            if (userPrefs.industries.length > 0 && booth.industry) {
                if (userPrefs.industries.includes(booth.industry)) {
                    score += 30;
                }
            }
            
            // Bookmarked bonus
            if (bookmarks.includes(booth.id)) {
                score += 20;
            }
            
            // Already submitted bonus
            if (userSubmissions.some(s => s.booth_id === booth.id)) {
                score += 10;
            }
            
            // AI matching score
            const matchResult = aiMatchingService.matchResumeToBooth(userId, booth.id);
            if (matchResult.success) {
                score += matchResult.matchScore * 0.4;
            }
            
            // Random factor for discovery (0-10)
            score += Math.random() * 10;
            
            return { ...booth, recommendationScore: Math.round(score) };
        });
        
        // Sort by score and return top recommendations
        return scoredBooths
            .sort((a, b) => b.recommendationScore - a.recommendationScore)
            .slice(0, 10);
    },
    
    recommendJobs: (userId) => {
        // Similar to booth recommendations but for specific job roles
        return recommendationService.recommendBooths(userId);
    }
};

// ============================================
// 4. QR CODE GENERATION & SCANNING
// ============================================

const qrService = {
    generateBoothQR: (boothId) => {
        try {
            // Get base URL more reliably
            const baseUrl = window.location.origin + window.location.pathname.substring(0, window.location.pathname.lastIndexOf('/'));
            const url = `${baseUrl}/booth.html?id=${boothId}`;
            // Using a QR code API (in production, use a library like qrcode.js)
            const qrApiUrl = `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(url)}`;
            return {
                success: true,
                qrUrl: qrApiUrl,
                url: url,
                boothId: boothId
            };
        } catch (error) {
            console.error('Error generating QR code:', error);
            return {
                success: false,
                message: 'Failed to generate QR code'
            };
        }
    },
    
    generateEventQR: (eventId) => {
        try {
            const baseUrl = window.location.origin + window.location.pathname.substring(0, window.location.pathname.lastIndexOf('/'));
            const url = `${baseUrl}/event-details.html?id=${eventId}`;
            const qrApiUrl = `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(url)}`;
            return {
                success: true,
                qrUrl: qrApiUrl,
                url: url,
                eventId: eventId
            };
        } catch (error) {
            console.error('Error generating QR code:', error);
            return {
                success: false,
                message: 'Failed to generate QR code'
            };
        }
    },
    
    scanQR: (qrData) => {
        try {
            const url = new URL(qrData);
            const boothId = url.searchParams.get('id');
            if (boothId) {
                return { success: true, type: 'booth', id: boothId };
            }
            return { success: false, message: 'Invalid QR code' };
        } catch {
            return { success: false, message: 'Invalid QR code format' };
        }
    }
};

// ============================================
// 5. MULTI-LANGUAGE INTERFACE (i18n)
// ============================================

const i18nService = {
    languages: {
        en: {
            name: 'English',
            flag: '🇺🇸'
        },
        es: {
            name: 'Español',
            flag: '🇪🇸'
        },
        fr: {
            name: 'Français',
            flag: '🇫🇷'
        },
        de: {
            name: 'Deutsch',
            flag: '🇩🇪'
        },
        zh: {
            name: '中文',
            flag: '🇨🇳'
        }
    },
    
    translations: {
        en: {
            'home': 'Home',
            'events': 'Events',
            'profile': 'Profile',
            'login': 'Login',
            'logout': 'Logout',
            'register': 'Sign Up',
            'edit_account': 'Edit Account',
            'username': 'Username',
            'password': 'Password',
            'save_changes': 'Save Changes',
            'cancel': 'Cancel',
            'recommended_booths': 'Recommended Booths',
            'ai_match_score': 'AI Match Score',
            'join_video_chat': 'Join Video Chat',
            'start_interview': 'Start Interview',
            'scan_qr_code': 'Scan QR Code',
            'generate_qr': 'Generate QR Code',
            'my_badges': 'My Badges',
            'participation_score': 'Participation Score',
            'leaderboard': 'Leaderboard'
        },
        es: {
            'home': 'Inicio',
            'events': 'Eventos',
            'profile': 'Perfil',
            'login': 'Iniciar Sesión',
            'logout': 'Cerrar Sesión',
            'register': 'Registrarse',
            'edit_account': 'Editar Cuenta',
            'username': 'Nombre de Usuario',
            'password': 'Contraseña',
            'save_changes': 'Guardar Cambios',
            'cancel': 'Cancelar',
            'recommended_booths': 'Puestos Recomendados',
            'ai_match_score': 'Puntuación de Coincidencia IA',
            'join_video_chat': 'Unirse a Video Chat',
            'start_interview': 'Iniciar Entrevista',
            'scan_qr_code': 'Escanear Código QR',
            'generate_qr': 'Generar Código QR',
            'my_badges': 'Mis Insignias',
            'participation_score': 'Puntuación de Participación',
            'leaderboard': 'Clasificación'
        },
        fr: {
            'home': 'Accueil',
            'events': 'Événements',
            'profile': 'Profil',
            'login': 'Connexion',
            'logout': 'Déconnexion',
            'register': 'S\'inscrire',
            'edit_account': 'Modifier le Compte',
            'username': 'Nom d\'utilisateur',
            'password': 'Mot de passe',
            'save_changes': 'Enregistrer les Modifications',
            'cancel': 'Annuler',
            'recommended_booths': 'Stands Recommandés',
            'ai_match_score': 'Score de Correspondance IA',
            'join_video_chat': 'Rejoindre le Chat Vidéo',
            'start_interview': 'Démarrer l\'Entretien',
            'scan_qr_code': 'Scanner le Code QR',
            'generate_qr': 'Générer le Code QR',
            'my_badges': 'Mes Badges',
            'participation_score': 'Score de Participation',
            'leaderboard': 'Classement'
        },
        de: {
            'home': 'Startseite',
            'events': 'Veranstaltungen',
            'profile': 'Profil',
            'login': 'Anmelden',
            'logout': 'Abmelden',
            'register': 'Registrieren',
            'edit_account': 'Konto Bearbeiten',
            'username': 'Benutzername',
            'password': 'Passwort',
            'save_changes': 'Änderungen Speichern',
            'cancel': 'Abbrechen',
            'recommended_booths': 'Empfohlene Stände',
            'ai_match_score': 'KI-Übereinstimmungspunktzahl',
            'join_video_chat': 'Video-Chat Beitreten',
            'start_interview': 'Interview Starten',
            'scan_qr_code': 'QR-Code Scannen',
            'generate_qr': 'QR-Code Generieren',
            'my_badges': 'Meine Abzeichen',
            'participation_score': 'Teilnahme-Punktzahl',
            'leaderboard': 'Bestenliste'
        },
        zh: {
            'home': '首页',
            'events': '活动',
            'profile': '个人资料',
            'login': '登录',
            'logout': '登出',
            'register': '注册',
            'edit_account': '编辑账户',
            'username': '用户名',
            'password': '密码',
            'save_changes': '保存更改',
            'cancel': '取消',
            'recommended_booths': '推荐展位',
            'ai_match_score': 'AI匹配分数',
            'join_video_chat': '加入视频聊天',
            'start_interview': '开始面试',
            'scan_qr_code': '扫描二维码',
            'generate_qr': '生成二维码',
            'my_badges': '我的徽章',
            'participation_score': '参与分数',
            'leaderboard': '排行榜'
        }
    },
    
    getCurrentLanguage: () => {
        return storage.get('language', 'en');
    },
    
    setLanguage: (lang) => {
        if (i18nService.languages[lang]) {
            storage.set('language', lang);
            return { success: true };
        }
        return { success: false, message: 'Language not supported' };
    },
    
    t: (key) => {
        const lang = i18nService.getCurrentLanguage();
        return i18nService.translations[lang]?.[key] || i18nService.translations.en[key] || key;
    },
    
    translatePage: () => {
        document.querySelectorAll('[data-i18n]').forEach(el => {
            const key = el.getAttribute('data-i18n');
            el.textContent = i18nService.t(key);
        });
        
        document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
            const key = el.getAttribute('data-i18n-placeholder');
            el.placeholder = i18nService.t(key);
        });
    }
};

// ============================================
// 6. GAMIFICATION SYSTEM
// ============================================

const gamificationService = {
    badges: {
        'first_login': { name: 'Welcome!', icon: '👋', description: 'Logged in for the first time', points: 10 },
        'first_rsvp': { name: 'Event Goer', icon: '📅', description: 'RSVP\'d to your first event', points: 20 },
        'first_resume': { name: 'Resume Master', icon: '📄', description: 'Submitted your first resume', points: 30 },
        'first_chat': { name: 'Chatterbox', icon: '💬', description: 'Sent your first chat message', points: 15 },
        'first_video': { name: 'Video Star', icon: '🎥', description: 'Joined your first video interview', points: 50 },
        'bookmark_5': { name: 'Collector', icon: '⭐', description: 'Bookmarked 5 booths', points: 25 },
        'bookmark_10': { name: 'Super Collector', icon: '🌟', description: 'Bookmarked 10 booths', points: 50 },
        'resume_5': { name: 'Job Seeker', icon: '🎯', description: 'Submitted 5 resumes', points: 75 },
        'resume_10': { name: 'Career Hunter', icon: '🏆', description: 'Submitted 10 resumes', points: 150 },
        'perfect_match': { name: 'Perfect Match', icon: '💎', description: 'Got 100% AI match score', points: 100 },
        'social_butterfly': { name: 'Social Butterfly', icon: '🦋', description: 'Chatted in 5 different booths', points: 60 },
        'early_bird': { name: 'Early Bird', icon: '🐦', description: 'RSVP\'d to event before it starts', points: 30 }
    },
    
    getUserStats: (userId) => {
        const stats = storage.get('userStats', {});
        return stats[userId] || {
            points: 0,
            badges: [],
            level: 1,
            participation_score: 0
        };
    },
    
    updateStats: (userId, updates) => {
        const allStats = storage.get('userStats', {});
        const userStats = allStats[userId] || gamificationService.getUserStats(userId);
        allStats[userId] = { ...userStats, ...updates };
        storage.set('userStats', allStats);
        return { success: true, stats: allStats[userId] };
    },
    
    awardBadge: (userId, badgeKey) => {
        const userStats = gamificationService.getUserStats(userId);
        
        if (userStats.badges.includes(badgeKey)) {
            return { success: false, message: 'Badge already earned' };
        }
        
        const badge = gamificationService.badges[badgeKey];
        if (!badge) {
            return { success: false, message: 'Invalid badge' };
        }
        
        userStats.badges.push(badgeKey);
        userStats.points += badge.points;
        userStats.level = Math.floor(userStats.points / 100) + 1;
        userStats.participation_score = userStats.points;
        
        gamificationService.updateStats(userId, userStats);
        
        return { success: true, badge, stats: userStats };
    },
    
    checkAndAwardBadges: (userId, action) => {
        const userStats = gamificationService.getUserStats(userId);
        const registrations = registrationService.getAll();
        const submissions = storage.get('resumeSubmissions', []);
        const messages = storage.get('chatMessages', {});
        const bookmarks = bookmarkService.getAll();
        const userRegistrations = registrations.filter(r => r.user_id === userId);
        const userSubmissions = submissions.filter(s => s.user_id === userId);
        const userBookmarks = bookmarks;
        
        const checks = {
            'first_login': !userStats.badges.includes('first_login'),
            'first_rsvp': userRegistrations.length === 1 && !userStats.badges.includes('first_rsvp'),
            'first_resume': userSubmissions.length === 1 && !userStats.badges.includes('first_resume'),
            'first_chat': Object.values(messages).some(room => room.some(m => m.user_id === userId)) && !userStats.badges.includes('first_chat'),
            'bookmark_5': bookmarks.length >= 5 && !userStats.badges.includes('bookmark_5'),
            'bookmark_10': bookmarks.length >= 10 && !userStats.badges.includes('bookmark_10'),
            'resume_5': userSubmissions.length >= 5 && !userStats.badges.includes('resume_5'),
            'resume_10': userSubmissions.length >= 10 && !userStats.badges.includes('resume_10')
        };
        
        const newBadges = [];
        Object.keys(checks).forEach(badgeKey => {
            if (checks[badgeKey]) {
                const result = gamificationService.awardBadge(userId, badgeKey);
                if (result.success) {
                    newBadges.push(result.badge);
                }
            }
        });
        
        return { success: true, newBadges };
    },
    
    getLeaderboard: (limit = 10) => {
        const allStats = storage.get('userStats', {});
        const users = storage.get('users', []);
        
        const leaderboard = Object.entries(allStats)
            .map(([userId, stats]) => {
                const user = users.find(u => u.id === parseInt(userId));
                return {
                    userId: parseInt(userId),
                    username: user?.username || 'Unknown',
                    points: stats.points || 0,
                    level: stats.level || 1,
                    badges: stats.badges?.length || 0
                };
            })
            .sort((a, b) => b.points - a.points)
            .slice(0, limit);
        
        return leaderboard;
    }
};

