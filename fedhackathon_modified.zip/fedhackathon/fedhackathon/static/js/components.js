// Shared UI Components

// Language Switcher Component
function createLanguageSwitcher() {
    const currentLang = i18nService.getCurrentLanguage();
    const languages = i18nService.languages;
    
    const switcher = document.createElement('div');
    switcher.className = 'language-switcher';
    switcher.innerHTML = `
        <button class="btn btn-secondary" onclick="showLanguageModal()" style="padding: 0.5rem 1rem; font-size: 0.9rem;">
            <span class="language-flag">${languages[currentLang]?.flag || '🌐'}</span>
            <span class="language-name">${languages[currentLang]?.name || 'Language'}</span>
            <i class="fas fa-chevron-down" style="margin-left: 0.5rem; font-size: 0.75rem;"></i>
        </button>
    `;
    
    return switcher;
}

function showLanguageModal() {
    const languages = i18nService.languages;
    const currentLang = i18nService.getCurrentLanguage();
    
    const modal = document.createElement('div');
    modal.className = 'modal';
    modal.id = 'languageModal';
    modal.innerHTML = `
        <div class="modal-content" style="max-width: 400px;">
            <div class="modal-header">
                <h2><i class="fas fa-globe"></i> Select Language</h2>
                <span class="close" onclick="closeModal('languageModal')">&times;</span>
            </div>
            <div class="modal-body" style="padding: 1.5rem;">
                ${Object.entries(languages).map(([code, lang]) => `
                    <button class="language-option ${code === currentLang ? 'active' : ''}" 
                            onclick="changeLanguage('${code}')"
                            style="width: 100%; padding: 1rem; margin-bottom: 0.5rem; text-align: left; background: var(--bg-primary); border: 2px solid var(--border-color); border-radius: var(--radius-md); cursor: pointer; transition: all var(--transition-base); display: flex; align-items: center; gap: 1rem;">
                        <span style="font-size: 1.5rem;">${lang.flag}</span>
                        <span style="flex: 1; font-weight: 600;">${lang.name}</span>
                        ${code === currentLang ? '<i class="fas fa-check" style="color: var(--primary-color);"></i>' : ''}
                    </button>
                `).join('')}
            </div>
        </div>
    `;
    document.body.appendChild(modal);
    showModal('languageModal');
    
    // Add hover effects
    modal.querySelectorAll('.language-option').forEach(btn => {
        btn.addEventListener('mouseenter', () => {
            if (!btn.classList.contains('active')) {
                btn.style.borderColor = 'var(--primary-color)';
                btn.style.background = 'var(--bg-secondary)';
            }
        });
        btn.addEventListener('mouseleave', () => {
            if (!btn.classList.contains('active')) {
                btn.style.borderColor = 'var(--border-color)';
                btn.style.background = 'var(--bg-primary)';
            }
        });
    });
}

function changeLanguage(langCode) {
    const result = i18nService.setLanguage(langCode);
    if (result.success) {
        closeModal('languageModal');
        showNotification(`Language changed to ${i18nService.languages[langCode].name}`, 'success');
        // Reload page to apply translations (in a real app, would use a framework)
        setTimeout(() => {
            window.location.reload();
        }, 1000);
    }
}

// Add language switcher styles
const style = document.createElement('style');
style.textContent = `
    .language-switcher {
        display: inline-flex;
    }
    
    .language-option.active {
        border-color: var(--primary-color) !important;
        background: linear-gradient(135deg, rgba(79, 70, 229, 0.1), rgba(124, 58, 237, 0.1)) !important;
    }
`;
document.head.appendChild(style);


