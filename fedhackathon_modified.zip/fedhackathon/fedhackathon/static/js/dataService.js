// Data Service - Handles all data operations using localStorage
// This replaces the backend API

let dataIdCounter = {
    users: 1,
    fairs: 1,
    booths: 1,
    registrations: 1,
    submissions: 1,
    messages: 1
};

// Initialize default data
function initializeData() {
    if (!storage.get('initialized')) {
        // Create default admin user
        const adminUser = {
            id: 1,
            username: 'admin',
            email: 'admin@careerfair.com',
            password: 'admin123', // In real app, this would be hashed
            role: 'admin',
            full_name: 'Administrator',
            created_at: new Date().toISOString()
        };
        
        const users = [adminUser];
        storage.set('users', users);
        storage.set('fairs', []);
        storage.set('booths', []);
        storage.set('registrations', []);
        storage.set('resumeSubmissions', []);
        storage.set('chatMessages', {});
        storage.set('initialized', true);
        storage.set('dataIdCounter', dataIdCounter);
    } else {
        dataIdCounter = storage.get('dataIdCounter', dataIdCounter);
    }
}

// User Management
const userService = {
    register: (userData) => {
        const users = storage.get('users', []);
        
        // Check if username exists
        if (users.find(u => u.username === userData.username)) {
            return { success: false, message: 'Username already exists' };
        }
        
        // Check if email exists
        if (users.find(u => u.email === userData.email)) {
            return { success: false, message: 'Email already exists' };
        }
        
        const newUser = {
            id: dataIdCounter.users++,
            ...userData,
            role: userData.role || 'user',
            created_at: new Date().toISOString()
        };
        
        users.push(newUser);
        storage.set('users', users);
        storage.set('dataIdCounter', dataIdCounter);
        
        return { success: true, user: newUser };
    },
    
    login: (username, password) => {
        const users = storage.get('users', []);
        const user = users.find(u => u.username === username && u.password === password);
        
        if (user) {
            // Don't send password back
            const { password: _, ...userWithoutPassword } = user;
            return { success: true, user: userWithoutPassword };
        }
        
        return { success: false, message: 'Invalid credentials' };
    },
    
    getCurrentUser: () => {
        return storage.get('currentUser', null);
    },
    
    setCurrentUser: (user) => {
        storage.set('currentUser', user);
    },
    
    logout: () => {
        storage.remove('currentUser');
    },
    
    updateUser: (userId, updates) => {
        const users = storage.get('users', []);
        const userIndex = users.findIndex(u => u.id === parseInt(userId));
        
        if (userIndex === -1) {
            return { success: false, message: 'User not found' };
        }
        
        const currentUser = users[userIndex];
        const updatedUser = { ...currentUser };
        
        // Update username if provided
        if (updates.username !== undefined) {
            // Check if new username already exists (excluding current user)
            const usernameExists = users.find(u => u.username === updates.username && u.id !== parseInt(userId));
            if (usernameExists) {
                return { success: false, message: 'Username already exists' };
            }
            updatedUser.username = updates.username.trim();
        }
        
        // Update password if provided
        if (updates.password !== undefined) {
            if (updates.password.length < 6) {
                return { success: false, message: 'Password must be at least 6 characters' };
            }
            updatedUser.password = updates.password;
        }
        
        // Update the user in the array
        users[userIndex] = updatedUser;
        storage.set('users', users);
        
        // Update current user session if this is the logged-in user
        const currentLoggedInUser = userService.getCurrentUser();
        if (currentLoggedInUser && currentLoggedInUser.id === parseInt(userId)) {
            // Don't send password back
            const { password: _, ...userWithoutPassword } = updatedUser;
            userService.setCurrentUser(userWithoutPassword);
        }
        
        // Don't send password back
        const { password: _, ...userWithoutPassword } = updatedUser;
        return { success: true, user: userWithoutPassword };
    }
};

// Career Fair Management
const fairService = {
    getAll: (role = 'user') => {
        const fairs = storage.get('fairs', []);
        if (role === 'admin') {
            return fairs;
        }
        // For users, only return upcoming and active fairs
        return fairs.filter(f => f.status === 'upcoming' || f.status === 'active');
    },
    
    getById: (id) => {
        const fairs = storage.get('fairs', []);
        return fairs.find(f => f.id === parseInt(id));
    },
    
    create: (fairData) => {
        const fairs = storage.get('fairs', []);
        const currentUser = userService.getCurrentUser();
        
        const newFair = {
            id: dataIdCounter.fairs++,
            ...fairData,
            created_by: currentUser.id,
            status: 'upcoming',
            created_at: new Date().toISOString()
        };
        
        fairs.push(newFair);
        storage.set('fairs', fairs);
        storage.set('dataIdCounter', dataIdCounter);
        
        return { success: true, fair: newFair };
    },
    
    update: (id, fairData) => {
        const fairs = storage.get('fairs', []);
        const index = fairs.findIndex(f => f.id === parseInt(id));
        
        if (index === -1) {
            return { success: false, message: 'Fair not found' };
        }
        
        fairs[index] = { ...fairs[index], ...fairData };
        storage.set('fairs', fairs);
        
        return { success: true, fair: fairs[index] };
    },
    
    delete: (id) => {
        const fairs = storage.get('fairs', []);
        const booths = storage.get('booths', []);
        const registrations = storage.get('registrations', []);
        
        // Delete associated booths
        const fairBooths = booths.filter(b => b.career_fair_id === parseInt(id));
        fairBooths.forEach(booth => {
            boothService.delete(booth.id);
        });
        
        // Delete associated registrations
        const fairRegistrations = registrations.filter(r => r.career_fair_id === parseInt(id));
        fairRegistrations.forEach(reg => {
            registrationService.delete(reg.id);
        });
        
        const filtered = fairs.filter(f => f.id !== parseInt(id));
        storage.set('fairs', filtered);
        
        return { success: true };
    }
};

// Booth Management
const boothService = {
    getByFairId: (fairId) => {
        const booths = storage.get('booths', []);
        return booths.filter(b => b.career_fair_id === parseInt(fairId));
    },
    
    getById: (id) => {
        const booths = storage.get('booths', []);
        return booths.find(b => b.id === parseInt(id));
    },
    
    create: (boothData) => {
        const booths = storage.get('booths', []);
        
        const newBooth = {
            id: dataIdCounter.booths++,
            ...boothData,
            career_fair_id: parseInt(boothData.career_fair_id),
            created_at: new Date().toISOString()
        };
        
        booths.push(newBooth);
        storage.set('booths', booths);
        storage.set('dataIdCounter', dataIdCounter);
        
        return { success: true, booth: newBooth };
    },
    
    update: (id, boothData) => {
        const booths = storage.get('booths', []);
        const index = booths.findIndex(b => b.id === parseInt(id));
        
        if (index === -1) {
            return { success: false, message: 'Booth not found' };
        }
        
        booths[index] = { ...booths[index], ...boothData };
        storage.set('booths', booths);
        
        return { success: true, booth: booths[index] };
    },
    
    delete: (id) => {
        const booths = storage.get('booths', []);
        const submissions = storage.get('resumeSubmissions', []);
        const messages = storage.get('chatMessages', {});
        
        // Delete associated submissions
        const boothSubmissions = submissions.filter(s => s.booth_id === parseInt(id));
        boothSubmissions.forEach(sub => {
            submissionService.delete(sub.id);
        });
        
        // Delete associated chat messages
        delete messages[id];
        storage.set('chatMessages', messages);
        
        const filtered = booths.filter(b => b.id !== parseInt(id));
        storage.set('booths', filtered);
        
        return { success: true };
    }
};

// Registration Management
const registrationService = {
    getAll: () => {
        return storage.get('registrations', []);
    },
    
    getByFairId: (fairId) => {
        const registrations = storage.get('registrations', []);
        return registrations.filter(r => r.career_fair_id === parseInt(fairId));
    },
    
    create: (fairId) => {
        const registrations = storage.get('registrations', []);
        const currentUser = userService.getCurrentUser();
        
        if (!currentUser) {
            return { success: false, message: 'Not authenticated' };
        }
        
        // Check if already registered
        const existing = registrations.find(
            r => r.user_id === currentUser.id && r.career_fair_id === parseInt(fairId)
        );
        
        if (existing) {
            return { success: false, message: 'Already registered' };
        }
        
        const newRegistration = {
            id: dataIdCounter.registrations++,
            user_id: currentUser.id,
            career_fair_id: parseInt(fairId),
            registered_at: new Date().toISOString()
        };
        
        registrations.push(newRegistration);
        storage.set('registrations', registrations);
        storage.set('dataIdCounter', dataIdCounter);
        
        return { success: true };
    },
    
    delete: (id) => {
        const registrations = storage.get('registrations', []);
        const filtered = registrations.filter(r => r.id !== parseInt(id));
        storage.set('registrations', filtered);
        return { success: true };
    }
};

// Resume Submission Management
const submissionService = {
    create: (boothId, fileData, coverLetter) => {
        const submissions = storage.get('resumeSubmissions', []);
        const currentUser = userService.getCurrentUser();
        
        if (!currentUser) {
            return { success: false, message: 'Not authenticated' };
        }
        
        const newSubmission = {
            id: dataIdCounter.submissions++,
            user_id: currentUser.id,
            booth_id: parseInt(boothId),
            resume_file: fileData.name,
            resume_data: fileData.data, // Base64 encoded file
            cover_letter: coverLetter || '',
            submitted_at: new Date().toISOString(),
            status: 'pending'
        };
        
        submissions.push(newSubmission);
        storage.set('resumeSubmissions', submissions);
        storage.set('dataIdCounter', dataIdCounter);
        
        return { success: true, message: 'Resume submitted successfully' };
    },
    
    delete: (id) => {
        const submissions = storage.get('resumeSubmissions', []);
        const filtered = submissions.filter(s => s.id !== parseInt(id));
        storage.set('resumeSubmissions', filtered);
        return { success: true };
    }
};

// Chat Management
const chatService = {
    getRoom: (boothId) => {
        const messages = storage.get('chatMessages', {});
        const roomId = `booth_${boothId}`;
        
        if (!messages[roomId]) {
            messages[roomId] = [];
            storage.set('chatMessages', messages);
        }
        
        return {
            room_id: roomId,
            name: `Booth ${boothId} Chat`,
            messages: messages[roomId] || []
        };
    },
    
    addMessage: (boothId, message) => {
        const messages = storage.get('chatMessages', {});
        const roomId = `booth_${boothId}`;
        const currentUser = userService.getCurrentUser();
        
        if (!currentUser) {
            return { success: false, message: 'Not authenticated' };
        }
        
        if (!messages[roomId]) {
            messages[roomId] = [];
        }
        
        const newMessage = {
            id: dataIdCounter.messages++,
            user_id: currentUser.id,
            username: currentUser.username,
            message: message,
            sent_at: new Date().toISOString()
        };
        
        messages[roomId].push(newMessage);
        storage.set('chatMessages', messages);
        storage.set('dataIdCounter', dataIdCounter);
        
        // Broadcast to other users (simulated)
        if (window.chatListeners && window.chatListeners[roomId]) {
            window.chatListeners[roomId].forEach(callback => {
                callback(newMessage);
            });
        }
        
        return { success: true, message: newMessage };
    },
    
    onMessage: (boothId, callback) => {
        const roomId = `booth_${boothId}`;
        if (!window.chatListeners) {
            window.chatListeners = {};
        }
        if (!window.chatListeners[roomId]) {
            window.chatListeners[roomId] = [];
        }
        window.chatListeners[roomId].push(callback);
    }
};

// Bookmark/Favorite Management
const bookmarkService = {
    toggle: (boothId) => {
        const bookmarks = storage.get('bookmarks', []);
        const index = bookmarks.indexOf(boothId);
        
        if (index > -1) {
            bookmarks.splice(index, 1);
            storage.set('bookmarks', bookmarks);
            return { success: true, bookmarked: false };
        } else {
            bookmarks.push(boothId);
            storage.set('bookmarks', bookmarks);
            return { success: true, bookmarked: true };
        }
    },
    
    isBookmarked: (boothId) => {
        const bookmarks = storage.get('bookmarks', []);
        return bookmarks.includes(boothId);
    },
    
    getAll: () => {
        return storage.get('bookmarks', []);
    }
};

// Analytics Service
const analyticsService = {
    trackBoothView: (boothId) => {
        const analytics = storage.get('analytics', {});
        if (!analytics.boothViews) {
            analytics.boothViews = {};
        }
        if (!analytics.boothViews[boothId]) {
            analytics.boothViews[boothId] = 0;
        }
        analytics.boothViews[boothId]++;
        storage.set('analytics', analytics);
    },
    
    getBoothViews: (boothId) => {
        const analytics = storage.get('analytics', {});
        return analytics.boothViews?.[boothId] || 0;
    },
    
    getAllBoothViews: () => {
        const analytics = storage.get('analytics', {});
        return analytics.boothViews || {};
    }
};

// Theme Service (Dark Mode)
const themeService = {
    init: () => {
        const theme = storage.get('theme', 'light');
        document.documentElement.setAttribute('data-theme', theme);
        return theme;
    },
    
    toggle: () => {
        const currentTheme = document.documentElement.getAttribute('data-theme') || 'light';
        const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
        document.documentElement.setAttribute('data-theme', newTheme);
        storage.set('theme', newTheme);
        return newTheme;
    },
    
    get: () => {
        return storage.get('theme', 'light');
    }
};

// Initialize on load
if (typeof storage !== 'undefined') {
    initializeData();
    themeService.init();
}

