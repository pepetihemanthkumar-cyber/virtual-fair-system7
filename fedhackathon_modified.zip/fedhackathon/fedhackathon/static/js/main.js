// Global utility functions
function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        const modalContent = modal.querySelector('.modal-content');
        if (modalContent) {
            // Smooth fade out
            modalContent.style.transition = 'all 0.2s cubic-bezier(0.4, 0, 0.2, 1)';
            modalContent.style.transform = 'translateY(20px)';
            modalContent.style.opacity = '0';
            setTimeout(() => {
                modal.style.display = 'none';
            }, 200);
        } else {
            modal.style.display = 'none';
        }
    }
}

function showModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = 'block';
        const modalContent = modal.querySelector('.modal-content');
        if (modalContent) {
            // Reset animation
            modalContent.style.transform = 'translateY(20px)';
            modalContent.style.opacity = '0';
            // Smooth fade in
            requestAnimationFrame(() => {
                modalContent.style.transition = 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)';
                modalContent.style.transform = 'translateY(0)';
                modalContent.style.opacity = '1';
            });
        }
    }
}

// Close modal when clicking outside (with smooth animation)
window.onclick = function(event) {
    if (event.target.classList.contains('modal')) {
        const modal = event.target;
        const modalContent = modal.querySelector('.modal-content');
        if (modalContent) {
            modalContent.style.transform = 'translateY(20px)';
            modalContent.style.opacity = '0';
            setTimeout(() => {
                modal.style.display = 'none';
            }, 200);
        } else {
            modal.style.display = 'none';
        }
    }
}

// Notification System with smooth animations
function showNotification(message, type = 'info', duration = 3000) {
    // Remove existing notifications
    const existing = document.querySelectorAll('.notification');
    existing.forEach(n => {
        n.classList.add('fade-out');
        setTimeout(() => n.remove(), 300);
    });
    
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.style.opacity = '0';
    notification.style.transform = 'translateX(120%)';
    
    const icon = {
        success: '<i class="fas fa-check-circle"></i>',
        error: '<i class="fas fa-exclamation-circle"></i>',
        info: '<i class="fas fa-info-circle"></i>',
        warning: '<i class="fas fa-exclamation-triangle"></i>'
    }[type] || '<i class="fas fa-info-circle"></i>';
    
    notification.innerHTML = `
        ${icon}
        <span>${message}</span>
        <button onclick="this.parentElement.classList.add('fade-out'); setTimeout(() => this.parentElement.remove(), 300);" style="margin-left: auto; background: none; border: none; color: inherit; cursor: pointer; font-size: 1.2rem; opacity: 0.8; transition: opacity 0.2s;">&times;</button>
    `;
    
    document.body.appendChild(notification);
    
    // Smooth slide-in animation
    requestAnimationFrame(() => {
        notification.style.transition = 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)';
        notification.style.opacity = '1';
        notification.style.transform = 'translateX(0)';
    });
    
    setTimeout(() => {
        notification.classList.add('fade-out');
        setTimeout(() => notification.remove(), 300);
    }, duration);
}

// Note: All API calls have been replaced with dataService functions
// See dataService.js for data management using localStorage

// Set button loading state
function setButtonLoading(button, isLoading) {
    if (isLoading) {
        button.disabled = true;
        button.classList.add('btn-loading');
        button.dataset.originalText = button.textContent;
        button.textContent = '';
    } else {
        button.disabled = false;
        button.classList.remove('btn-loading');
        if (button.dataset.originalText) {
            button.textContent = button.dataset.originalText;
        }
    }
}

// Form Validation Utilities
const validators = {
    required: (value) => {
        if (!value || value.trim() === '') {
            return 'This field is required';
        }
        return null;
    },
    
    minLength: (min) => (value) => {
        if (value && value.length < min) {
            return `Must be at least ${min} characters`;
        }
        return null;
    },
    
    maxLength: (max) => (value) => {
        if (value && value.length > max) {
            return `Must be no more than ${max} characters`;
        }
        return null;
    },
    
    email: (value) => {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (value && !emailRegex.test(value)) {
            return 'Please enter a valid email address';
        }
        return null;
    },
    
    url: (value) => {
        if (!value) return null;
        try {
            new URL(value);
            return null;
        } catch {
            return 'Please enter a valid URL';
        }
    },
    
    password: (value) => {
        if (!value) return null;
        if (value.length < 6) {
            return 'Password must be at least 6 characters';
        }
        // Optional: Uncomment for stronger password requirements
        // if (!/(?=.*[a-z])/.test(value)) {
        //     return 'Password must contain at least one lowercase letter';
        // }
        // if (!/(?=.*[A-Z])/.test(value)) {
        //     return 'Password must contain at least one uppercase letter';
        // }
        // if (!/(?=.*\d)/.test(value)) {
        //     return 'Password must contain at least one number';
        // }
        return null;
    },
    
    username: (value) => {
        if (!value) return null;
        const usernameRegex = /^[a-zA-Z0-9_]{3,20}$/;
        if (!usernameRegex.test(value)) {
            return 'Username must be 3-20 characters (letters, numbers, underscore only)';
        }
        return null;
    },
    
    dateRange: (startField, endField) => (value, form) => {
        const startDate = new Date(form[startField].value);
        const endDate = new Date(form[endField].value);
        if (endDate <= startDate) {
            return 'End date must be after start date';
        }
        return null;
    }
};

// Validate field
function validateField(field, rules = []) {
    const value = field.value;
    let error = null;
    
    for (const rule of rules) {
        if (typeof rule === 'function') {
            error = rule(value);
        } else if (typeof rule === 'string' && validators[rule]) {
            error = validators[rule](value);
        }
        if (error) break;
    }
    
    // Update UI
    const errorElement = field.parentElement.querySelector('.field-error');
    const successElement = field.parentElement.querySelector('.field-success');
    
    if (error) {
        field.classList.remove('valid');
        field.classList.add('invalid');
        if (errorElement) {
            errorElement.textContent = error;
        } else {
            const errorDiv = document.createElement('span');
            errorDiv.className = 'field-error';
            errorDiv.textContent = error;
            field.parentElement.appendChild(errorDiv);
        }
        if (successElement) successElement.remove();
    } else {
        field.classList.remove('invalid');
        if (value) {
            field.classList.add('valid');
        }
        if (errorElement) errorElement.remove();
        if (successElement) successElement.remove();
    }
    
    return !error;
}

// Validate form
function validateForm(form, rules) {
    let isValid = true;
    const fields = form.querySelectorAll('input, textarea, select');
    
    fields.forEach(field => {
        if (rules[field.name] || rules[field.id]) {
            const fieldRules = rules[field.name] || rules[field.id] || [];
            if (!validateField(field, fieldRules)) {
                isValid = false;
            }
        }
    });
    
    return isValid;
}

// Setup real-time validation
function setupFormValidation(form, rules) {
    const fields = form.querySelectorAll('input, textarea, select');
    
    fields.forEach(field => {
        if (rules[field.name] || rules[field.id]) {
            const fieldRules = rules[field.name] || rules[field.id] || [];
            
            field.addEventListener('blur', () => {
                validateField(field, fieldRules);
            });
            
            field.addEventListener('input', () => {
                if (field.classList.contains('invalid')) {
                    validateField(field, fieldRules);
                }
            });
        }
    });
}

// Format date
function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

// Format relative time
function formatRelativeTime(dateString) {
    const date = new Date(dateString);
    const now = new Date();
    const diff = now - date;
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);
    
    if (minutes < 1) return 'Just now';
    if (minutes < 60) return `${minutes}m ago`;
    if (hours < 24) return `${hours}h ago`;
    if (days < 7) return `${days}d ago`;
    return formatDate(dateString);
}

// LocalStorage utilities
const storage = {
    set: (key, value) => {
        try {
            localStorage.setItem(key, JSON.stringify(value));
        } catch (e) {
            console.error('Error saving to localStorage:', e);
        }
    },
    
    get: (key, defaultValue = null) => {
        try {
            const item = localStorage.getItem(key);
            return item ? JSON.parse(item) : defaultValue;
        } catch (e) {
            console.error('Error reading from localStorage:', e);
            return defaultValue;
        }
    },
    
    remove: (key) => {
        try {
            localStorage.removeItem(key);
        } catch (e) {
            console.error('Error removing from localStorage:', e);
        }
    }
};


