# Virtual Career Fair Platform

A comprehensive frontend-only web application for hosting virtual career fairs and networking events. The platform enables companies to showcase their opportunities and allows job seekers to explore booths, submit resumes, and engage in chat conversations.

## Features

### Admin Features
- **Career Fair Management**: Create, edit, and manage career fair schedules
- **Booth Management**: Add and manage company booths for each career fair
- **Registration Tracking**: View all user registrations for career fairs
- **Dashboard**: Comprehensive admin dashboard for managing all aspects of events

### User Features (Students/Job Seekers)
- **Fair Registration**: Browse and register for upcoming career fairs
- **Company Booths**: Explore virtual company booths with detailed information
- **Resume Submission**: Submit resumes directly to companies of interest
- **Live Chat**: Chat functionality within company booths for networking
- **Dashboard**: Personal dashboard to track registered fairs and submissions

## Technology Stack

- **Frontend**: HTML5, CSS3, JavaScript (Vanilla JS)
- **Data Storage**: localStorage (browser-based)
- **No Backend Required**: Fully client-side application

## Installation

1. **Clone or download the repository**
   ```bash
   git clone <repository-url>
   cd fedhackathon
   ```

2. **Open the application**
   - Simply open `index.html` in your web browser
   - Or use a local web server:
     ```bash
     # Using Python
     python -m http.server 8000
     
     # Using Node.js
     npx http-server
     
     # Using PHP
     php -S localhost:8000
     ```

3. **Access the application**
   - Open your browser and navigate to `http://localhost:8000` (or the port you chose)

## Default Admin Account

When you first open the application, a default admin account is automatically created:

- **Username**: `admin`
- **Password**: `admin123`

**⚠️ Important**: This is a frontend-only demo. All data is stored in your browser's localStorage.

## Project Structure

```
fedhackathon/
├── index.html              # Home page
├── login.html              # Login page
├── register.html           # Registration page
├── admin-dashboard.html    # Admin dashboard
├── user-dashboard.html     # User dashboard
├── static/                 # Static files
│   ├── css/
│   │   └── style.css       # Main stylesheet
│   └── js/
│       ├── main.js         # Utility functions
│       ├── dataService.js  # Data management (localStorage)
│       ├── admin.js        # Admin functionality
│       └── user.js         # User functionality
└── README.md               # This file
```

## Usage Guide

### For Administrators

1. **Login** with admin credentials (username: `admin`, password: `admin123`)
2. **Create a Career Fair**:
   - Click "Create Career Fair" button
   - Fill in title, description, start and end dates
   - Save the career fair

3. **Add Company Booths**:
   - Click "Manage Booths" on a career fair
   - Add company information (name, description, industry, website, logo)
   - Each booth automatically gets a chat room

4. **Monitor Registrations**:
   - View the "Registrations" tab to see all user registrations
   - Track which users have registered for which fairs

### For Users (Job Seekers)

1. **Register an Account**:
   - Click "Sign Up" on the home page
   - Fill in your details and register
   - Login to access the platform

2. **Browse Career Fairs**:
   - View all upcoming and active career fairs
   - See fair details, dates, and number of companies

3. **Register for a Fair**:
   - Click "Register Now" on any fair
   - Once registered, you can access company booths

4. **Explore Company Booths**:
   - Click on a career fair to see all company booths
   - View company information, industry, and descriptions

5. **Submit Resumes**:
   - Visit a company booth
   - Upload your resume (PDF, DOC, or DOCX)
   - Optionally include a cover letter
   - Submit directly to the company

6. **Chat with Others**:
   - Use the chat feature in each booth
   - Network with other job seekers
   - Messages are stored in localStorage

## Data Storage

All data is stored in the browser's localStorage:
- User accounts
- Career fairs
- Company booths
- Registrations
- Resume submissions
- Chat messages

**Note**: Data is browser-specific and will be cleared if you clear your browser data.

## Features

- ✅ **No Backend Required**: Fully client-side application
- ✅ **Real-time Form Validation**: Comprehensive validation with instant feedback
- ✅ **Beautiful UI**: Modern, responsive design
- ✅ **Data Persistence**: localStorage for data storage
- ✅ **Smooth Animations**: Polished user experience
- ✅ **Error Handling**: Comprehensive error handling and user feedback

## Browser Compatibility

Works in all modern browsers:
- Chrome/Edge (recommended)
- Firefox
- Safari
- Opera

## Security Note

This is a **frontend-only demo application**. In a production environment:
- Passwords should be hashed (currently stored in plain text)
- Data should be stored on a secure backend server
- Authentication should use secure tokens
- File uploads should be validated server-side

## Troubleshooting

### Data Not Persisting
- Make sure your browser allows localStorage
- Check browser settings for localStorage permissions
- Try clearing browser cache and reloading

### Features Not Working
- Make sure JavaScript is enabled in your browser
- Check browser console for errors (F12)
- Try refreshing the page

## License

This project is open source and available for educational purposes.

## Support

For issues or questions, please create an issue in the repository.
