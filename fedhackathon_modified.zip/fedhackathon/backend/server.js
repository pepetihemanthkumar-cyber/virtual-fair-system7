require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const app = express();

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({extended:true}));

const PORT = process.env.PORT || 5000;
const MONGO = process.env.MONGO_URI || 'mongodb://localhost:27017/fedhackathon';

// Connect to MongoDB
mongoose.connect(MONGO, {useNewUrlParser:true, useUnifiedTopology:true})
  .then(()=>console.log('MongoDB connected'))
  .catch(err=>console.error('MongoDB connection error:', err));

// Models
const User = require('./models/User');
const Event = require('./models/Event');
const Booth = require('./models/Booth');
const Message = require('./models/Message');

// Simple routes
app.get('/', (req,res)=> res.json({ok:true, msg:'FedHackathon backend is running'}));

// Auth routes
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

app.post('/api/register', async (req,res)=>{
  try{
    const {name, email, password} = req.body;
    if(!email || !password) return res.status(400).json({error:'email and password required'});
    let user = await User.findOne({email});
    if(user) return res.status(400).json({error:'user exists'});
    const hashed = await bcrypt.hash(password, 10);
    user = new User({name, email, password:hashed});
    await user.save();
    res.json({ok:true, userId:user._id});
  }catch(err){
    console.error(err);
    res.status(500).json({error:'server error'});
  }
});

app.post('/api/login', async (req,res)=>{
  try{
    const {email, password} = req.body;
    const user = await User.findOne({email});
    if(!user) return res.status(400).json({error:'invalid credentials'});
    const match = await bcrypt.compare(password, user.password);
    if(!match) return res.status(400).json({error:'invalid credentials'});
    const token = jwt.sign({id:user._id, email:user.email}, process.env.JWT_SECRET || 'secret', {expiresIn:'7d'});
    res.json({ok:true, token, user:{id:user._id, name:user.name, email:user.email}});
  }catch(err){
    console.error(err);
    res.status(500).json({error:'server error'});
  }
});

// Middleware to protect routes
const auth = (req,res,next)=>{
  const authHeader = req.headers.authorization;
  if(!authHeader) return res.status(401).json({error:'no token'});
  const token = authHeader.split(' ')[1];
  try{
    const payload = jwt.verify(token, process.env.JWT_SECRET || 'secret');
    req.user = payload;
    next();
  }catch(e){
    return res.status(401).json({error:'invalid token'});
  }
};

// Events
app.get('/api/events', async (req,res)=>{
  const events = await Event.find().limit(100).lean();
  res.json(events);
});

app.post('/api/events', auth, async (req,res)=>{
  const ev = new Event({...req.body, createdBy: req.user.id});
  await ev.save();
  res.json(ev);
});

// Booths
app.get('/api/booths', async (req,res)=>{
  const booths = await Booth.find().limit(200).lean();
  res.json(booths);
});

app.post('/api/booths', auth, async (req,res)=>{
  const b = new Booth({...req.body, createdBy: req.user.id});
  await b.save();
  res.json(b);
});

// Chat messages (simple)
app.get('/api/messages/:room', async (req,res)=>{
  const msgs = await Message.find({room: req.params.room}).sort('createdAt').limit(500).lean();
  res.json(msgs);
});

app.post('/api/messages', auth, async (req,res)=>{
  const m = new Message({...req.body, sender: req.user.id});
  await m.save();
  res.json(m);
});

app.listen(PORT, ()=>console.log('Server listening on', PORT));
