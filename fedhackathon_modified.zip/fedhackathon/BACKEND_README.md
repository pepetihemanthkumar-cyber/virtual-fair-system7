# FedHackathon — Backend added

A simple Express + MongoDB backend was added under `backend/`.

## What was added
- `backend/server.js` — main express server with routes:
  - `POST /api/register` — register user
  - `POST /api/login` — login (returns JWT)
  - `GET /api/events` — list events
  - `POST /api/events` — create event (requires Authorization: Bearer <token>)
  - `GET /api/booths` — list booths
  - `POST /api/booths` — create booth (requires auth)
  - `GET /api/messages/:room` — list messages
  - `POST /api/messages` — create message (requires auth)

- `backend/models/*` — Mongoose models for User, Event, Booth, Message
- `backend/.env.example` — environment variables example

## How to run locally

1. Make sure you have Node.js (16+) and MongoDB running locally.

2. From project root:
```bash
cd fedhackathon/fedhackathon/backend
npm install
# copy .env.example to .env and tweak if needed
cp .env.example .env
# start
npm run start
```

3. Open the frontend `index.html` (or serve via a simple static server) and use the Register / Login forms.
- Register at `/register.html`
- Login at `/login.html`

## Notes
- The frontend is unchanged except for small fetch-based scripts added to `register.html` and `login.html`.
- The backend uses JWT stored in `localStorage` by the frontend. For production, use secure cookies and HTTPS.
- If you want, I can add docker-compose to run MongoDB + backend together.

